<?php

defined('ABSPATH') or die();

/*
  Plugin Name: Ajax Base Like and Dislike System 
  Description: Like and Dislike system for Post, Custom Post Types, Pages, Media 
  Version:     1.0.8
  Author:      Muhammad Waleed
  Author URI:  #
  License:     GPL2
  Text Domain: posts-like-dislike
 */


if (!class_exists('PLD_Comments_like_dislike')) {
    class PLD_Comments_like_dislike {
        public function __construct() {
            $this->define_constants();
            $this->includes();
        }

        /**
         * Include all the necessary files
         *
         * @since 1.0.0
         */
        public function includes() {
            require_once PLD_PATH . '/inc/classes/pld-library.php';
            require_once PLD_PATH . '/inc/classes/pld-activation.php';
            require_once PLD_PATH . 'inc/classes/pld-init.php';
            require_once PLD_PATH . 'inc/classes/pld-admin.php';
            require_once PLD_PATH . 'inc/classes/pld-enqueue.php';
            require_once PLD_PATH . 'inc/classes/pld-hook.php';
            require_once PLD_PATH . 'inc/classes/pld-ajax.php';
        }

        /**
         * Define necessary constants
         *
         * @since 1.0.0
         */
        public function define_constants() {
            defined('PLD_PATH') or define('PLD_PATH', plugin_dir_path(__FILE__));
            defined('PLD_IMG_DIR') or define('PLD_IMG_DIR', plugin_dir_url(__FILE__) . 'images');
            defined('PLD_CSS_DIR') or define('PLD_CSS_DIR', plugin_dir_url(__FILE__) . 'css');
            defined('PLD_JS_DIR') or define('PLD_JS_DIR', plugin_dir_url(__FILE__) . 'js');
            defined('PLD_VERSION') or define('PLD_VERSION', '1.0.8');
            defined('PLD_TD') or define('PLD_TD', 'posts-like-dislike');
            defined('PLD_BASENAME') or define('PLD_BASENAME', plugin_basename(__FILE__));
        }
    }

    $pld_object = new PLD_Comments_like_dislike();
}

function custom_loop(){
    $args = array(  
        'post_type' => 'car',
        'post_status' => 'publish',
        'posts_per_page' => 8, 
        'orderby' => 'title', 
        'order' => 'ASC', 
    );
    $loop = new WP_Query( $args ); 
    while ( $loop->have_posts() ) : $loop->the_post(); 
    ?>
    <div class="card" style="width: 18rem;">
    <?php the_post_thumbnail(); ?>
      <div class="card-body">
       <a href="<?php the_permalink( )?>"> <h2 class="card-title"><?php print the_title(); ?></h2></a>
        <p class="card-text"><?php the_excerpt();?></p>
        <a href="<?php the_permalink( )?>" class="btn btn-primary">Details</a>
      </div>
    </div>
    <?php endwhile; 
    wp_reset_postdata(); 

}
add_shortcode( 'post', 'custom_loop' );

// function that runs when shortcode is called
function wpb_demo_shortcode() { 
  
    // Things that you want to do.
    $args = array(  
        'post_type' => 'car',
        'post_status' => 'publish',
        'posts_per_page' => 8, 
        'orderby' => 'title', 
        'order' => 'ASC', 
    );

    $loop = new WP_Query( $args ); ?>

    <div class="grid-container">
    <?php
    while ( $loop->have_posts() ) : $loop->the_post(); 
    ?>
    
    <div class="grid-item">
    <?php the_post_thumbnail(); ?>
      <div class="card-body">
       <a href="<?php the_permalink( )?>"> <h2 class="card-title"><?php print the_title(); ?></h2></a>
        <p class="card-text"><?php the_excerpt();?></p>
        <a href="<?php the_permalink( )?>" class="btn btn-primary">Details</a>
      </div>
    </div>

    <?php endwhile; ?>
</div>
<?php
wp_reset_postdata(); 
      
    // Output needs to be return
    
    }
    // register shortcode
    add_shortcode('post_show', 'wpb_demo_shortcode');