<?php

defined( 'ABSPATH' ) or die( 'No script kiddies please!!' );
if ( !class_exists( 'PLD_Activation' ) ) {

	class PLD_Activation extends PLD_Library {

		/**
		 * Includes all the activation tasks
		 * 
		 * @since 1.0.0
		 */
		function __construct() {
			register_activation_hook( PLD_PATH . 'posts-like-dislike.php', array( $this, 'activation_tasks' ) );

			add_action( 'init', 'car_register_post_type' );
function car_register_post_type() {
	$args = [
		'label'  => esc_html__( 'Cars', 'text-domain' ),
		'labels' => [
			'menu_name'          => esc_html__( 'Cars', 'car' ),
			'name_admin_bar'     => esc_html__( 'car', 'car' ),
			'add_new'            => esc_html__( 'Add car', 'car' ),
			'add_new_item'       => esc_html__( 'Add new car', 'car' ),
			'new_item'           => esc_html__( 'New car', 'car' ),
			'edit_item'          => esc_html__( 'Edit car', 'car' ),
			'view_item'          => esc_html__( 'View car', 'car' ),
			'update_item'        => esc_html__( 'View car', 'car' ),
			'all_items'          => esc_html__( 'All Cars', 'car' ),
			'search_items'       => esc_html__( 'Search Cars', 'car' ),
			'parent_item_colon'  => esc_html__( 'Parent car', 'car' ),
			'not_found'          => esc_html__( 'No Cars found', 'car' ),
			'not_found_in_trash' => esc_html__( 'No Cars found in Trash', 'car' ),
			'name'               => esc_html__( 'Cars', 'car' ),
			'singular_name'      => esc_html__( 'car', 'car' ),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'capability_type'     => 'post',
		'hierarchical'        => false,
		'has_archive'         => true,
		'query_var'           => true,
		'can_export'          => true,
		'rewrite_no_front'    => false,
		'show_in_menu'        => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-smiley',
		'supports' => [
			'title',
			'editor',
			'thumbnail',
			'custom-fields',
		],
		'taxonomies' => [
			'category',
			'tag',
		],
		'rewrite' => true
	];

	register_post_type( 'car', $args );
}
		}
		
		/**
		 * Store default settings in database on activation
		 * 
		 * @since 1.0.0
		 */
		function activation_tasks() {
			$default_settings = $this->get_default_settings();
			if(!get_option('pld_settings')){
				update_option('pld_settings',$default_settings);
			}
		}

		

	}

	new PLD_Activation();
}